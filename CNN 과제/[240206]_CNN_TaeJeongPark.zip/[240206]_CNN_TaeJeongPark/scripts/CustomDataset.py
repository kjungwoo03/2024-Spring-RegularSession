import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor

from PIL import Image

"""
MetaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):

    def __init__(self, dataset_direc:str, df:pd.DataFrame, transform = None) -> None: 
        self.dataset_direc= dataset_direc

        self.df = df.reset_index(drop=True)

        self.to_tensor = ToTensor() 

        self.transform = transform # 변환함수

    def __len__(self) -> int : 
        return len(self.df)
    

    def __getitem__(self, idx:int):
        filename = self.df.iloc[idx, 0] # Filename : 0
        # strlabel = self.df.iloc[idx, 1] # StrLabel : 1
        label = self.df.iloc[idx,2] # Label : 2

        image_path = os.path.join(self.dataset_direc, self.df.iloc[idx, 1], filename)
        image = Image.open(image_path) # 이미지 파일의 경로를 받음
        image = self.to_tensor(image)

        if self.transform: 
            image = self.transform(image)

        return image, label