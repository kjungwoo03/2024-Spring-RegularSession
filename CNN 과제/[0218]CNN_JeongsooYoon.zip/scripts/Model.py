import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    expansion = 4
    def __init__(self, in_channels, out_channels, stride= 1, ith_block= 1):
        super().__init__()
        self.residual_function = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride = stride, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels*ResBottleNeck.expansion, kernel_size=1, stride=1, bias=False),
            nn.BatchNorm2d(out_channels*ResBottleNeck.expansion),
        )

        self.shortcut = nn.Sequential()
        if stride == 1 and ith_block == 1:
            self.shortcut = nn.Sequential(nn.Conv2d(in_channels, out_channels * ResBottleNeck.expansion, kernel_size=1, stride=1), 
                                          nn.BatchNorm2d(out_channels*ResBottleNeck.expansion))
        if stride != 1 or in_channels != out_channels * ResBottleNeck.expansion: 
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, out_channels*ResBottleNeck.expansion, kernel_size=1, stride=stride, bias=False), 
                nn.BatchNorm2d(out_channels*ResBottleNeck.expansion)
            )

        self.relu = nn.ReLU()    

    def forward(self, x):
        x = self.residual_function(x) + self.shortcut(x)
        x = self.relu(x)
        return x



class ResNet50(nn.Module):
    def __init__(self, block, num_block = [3,4,6,3], zero_init_residual=True):
        super().__init__()

        self.in_channels = 64 
        
        self.conv1 = nn.Sequential(
            nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace = True),
            nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        )
        
        self.conv2 = self._make_layer(block, 64, num_block[0], 1)
        self.conv3 = self._make_layer(block, 128, num_block[1], 2)
        self.conv4 = self._make_layer(block, 256, num_block[2], 2)
        self.conv5 = self._make_layer(block, 512, num_block[3], 2)
        
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(512 * block.expansion, out_features=1, bias=True)  # 마지막 fc 레이어의 출력 크기를 1로 설정하여 sigmoid에 들어갈 값으로 변환
        
        #weight initialization
        #if zero_init_residual:
            #self.initialize_weights()
        
    """
    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        x = self.conv3(out)
        x = self.conv4(x)
        x = self.conv5(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)
        return x
    """
    def forward(self, x):
        out = self.conv1(x)
        out = self.conv2(out)
        out = self.conv3(out)
        out = self.conv4(out)
        out = self.conv5(out)
        out = self.avgpool(out)
        out = out.view(out.size(0), -1)
        out = self.fc(out)
        return out
 
   
    
    def _make_layer(self, block, out_channels, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks -1)
        layers = []
        ith_block = 1
        for stride in strides:
            layers.append(block(self.in_channels, out_channels, stride, ith_block))
            self.in_channels = out_channels * block.expansion
            ith_block = ith_block + 1
        
        return nn.Sequential(*layers)

def resnet50():
    return ResNet50(ResBottleNeck, [3,4,6,3])