import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

def conv3x3(in_channels, out_channels, stride = 1):
    return nn.Conv2d(in_channels=in_channels,
                    out_channels=out_channels, kernel_size=3,
                    stride=stride, padding=1, bias=False)
    
def conv1x1(in_channels, out_channels, stride = 1):
    return nn.Conv2d(in_channels=in_channels,
                    out_channels=out_channels, kernel_size=1,
                    stride=stride, padding=0, bias=False)


class BasicBlock(nn.Module):
    def __init__(self, in_channels, red_channels, out_channels, stride=1, donwsample=None):
        super(BasicBlock, self).__init__()
        
        self.relu = nn.ReLU(inplace = True)
        self.conv1 = conv1x1(in_channels, in_channels, stride)
        self.bn1 = nn.BatchNorm2d(in_channels)
        self.conv2 = conv3x3(in_channels, red_channels, stride)
        self.bn2 = nn.BatchNorm2d(red_channels)
        self.conv3 = conv1x1(red_channels, out_channels, stride)
        
        self.donwsample = donwsample
    
    def forward(self, x):
        identity = x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)
        
        out = self.conv3(out)
        
        if self.donwsample is not None:
            identity = self.donwsample(x)
        
        out += identity
        out = self.relu(out)
        return out
        

class ResBottleNeck(nn.Module):
    def __init__(self, in_channels, red_channels, out_channels, stride=1, donwsample=None) -> None:
        super(ResBottleNeck, self).__init__()
        self.relu = nn.ReLU(inplace = True)
        # make the feature map size as half
        self.conv1 = conv1x1(in_channels, red_channels, stride)
        self.bn1 = nn.BatchNorm2d(red_channels)
        self.conv2 = conv3x3(red_channels, red_channels, stride=2)
        self.bn2 = nn.BatchNorm2d(red_channels)
        self.conv3 = conv1x1(red_channels, out_channels, stride)
        
        self.donwsample = donwsample
        
    def forward(self, x):
        identity = x
        
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)
        
        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)
        
        out = self.conv3(out)
        
        if self.donwsample is not None:
            identity = self.donwsample(x)
        
        out += identity
        out = self.relu(out)
        return out
    

class ResNet50(nn.Module):
    def __init__(self) -> None:
        super(ResNet50,self).__init__()
        self.conv1 = nn.Sequential(
                        nn.Conv2d(in_channels=1, out_channels=64, kernel_size=7,
                          stride=2, padding=3, bias=True),
                        nn.BatchNorm2d(64),
                        nn.ReLU(inplace = True),
                        nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
                    )
        
        self.conv2_1 = BasicBlock(in_channels = 64, red_channels=64, out_channels=256,
                                  stride=1, donwsample=conv1x1(in_channels=64, out_channels=256))
        self.conv2_2 = BasicBlock(in_channels = 256, red_channels=64, out_channels=256,
                            stride=1, donwsample=None)
        self.conv2_3 = BasicBlock(in_channels = 256, red_channels=64, out_channels=256,
                            stride=1, donwsample=None)
     
        self.conv3_1 = ResBottleNeck(in_channels = 256, red_channels=128, out_channels=512,
                            stride=1, donwsample=conv1x1(in_channels=256, out_channels=512, stride = 2))
        self.conv3_2 = BasicBlock(in_channels = 512, red_channels=128, out_channels=512,
                            stride=1, donwsample=None)   
        self.conv3_3 = BasicBlock(in_channels = 512, red_channels=128, out_channels=512,
                            stride=1, donwsample=None)
        self.conv3_4 = BasicBlock(in_channels = 512, red_channels=128, out_channels=512,
                            stride=1, donwsample=None)

        self.conv4_1 = ResBottleNeck(in_channels = 512, red_channels=256, out_channels=1024,
                            stride=1, donwsample=conv1x1(in_channels=512, out_channels=1024, stride = 2))
        self.conv4_2 = BasicBlock(in_channels = 1024, red_channels=256, out_channels=1024,
                            stride=1, donwsample=None)
        self.conv4_3 = BasicBlock(in_channels = 1024, red_channels=256, out_channels=1024,
                            stride=1, donwsample=None)
        self.conv4_4 = BasicBlock(in_channels = 1024, red_channels=256, out_channels=1024,
                            stride=1, donwsample=None)
        self.conv4_5 = BasicBlock(in_channels = 1024, red_channels=256, out_channels=1024,
                            stride=1, donwsample=None)
        self.conv4_6 = BasicBlock(in_channels = 1024, red_channels=256, out_channels=1024,
                            stride=1, donwsample=None)

        self.conv5_1 = ResBottleNeck(in_channels = 1024, red_channels=512, out_channels=2048,
                            stride=1, donwsample=conv1x1(in_channels=1024, out_channels=2048, stride = 2))
        self.conv5_2 = BasicBlock(in_channels = 2048, red_channels=512, out_channels=2048,
                            stride=1, donwsample=None)
        self.conv5_3 = BasicBlock(in_channels = 2048, red_channels=512, out_channels=2048,
                            stride=1, donwsample=None)
        
        self.avgpool = nn.AdaptiveAvgPool2d((1,1))
        self.fc = nn.Linear(2048, 1)

    def forward(self,x):
        
        #########################
        #  Froward Propagation  #
        #########################
        x = self.conv1(x)
        x = self.conv2_1(x)
        x = self.conv2_2(x)
        x = self.conv2_3(x)
        
        x = self.conv3_1(x)
        x = self.conv3_2(x)
        x = self.conv3_3(x)
        x = self.conv3_4(x)
        
        x = self.conv4_1(x)
        x = self.conv4_2(x)
        x = self.conv4_3(x)
        x = self.conv4_4(x)
        x = self.conv4_5(x)
        x = self.conv4_6(x)
        
        x = self.conv5_1(x)
        x = self.conv5_2(x)
        x = self.conv5_3(x)
        
        x = self.avgpool(x).squeeze(dim = -1).squeeze(dim = -1)
        x = self.fc(x).squeeze(dim = -1)
        
        return x
    

