import torch 
import torch.nn as nn
import torch.nn.functional as F 

import pandas as pd 
import numpy as np 

""" 
[Batch, Channel, 224, 224]의 input을 받았을 때, 
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self, in_channels, out_channels, stage, initial):
        super(ResBottleNeck, self).__init__()
        
        if stage == 2 and initial == True: # in_channels = 64, out_channels = 256
            self.conv_first_layer = nn.Conv2d(in_channels = in_channels, out_channels = in_channels,
                                              kernel_size = 1, stride = 1, padding = 0)
            self.skip_connection = nn.Conv2d(in_channels = in_channels, out_channels = out_channels,
                                              kernel_size = 1, stride = 1, padding = 0)
            self.batchnorm_first_layer = nn.BatchNorm2d(in_channels)
            middle_channels = in_channels
        elif stage == 2 and initial == False: # in_channels = 256, out_channels = 256, middle = 64
            self.conv_first_layer = nn.Conv2d(in_channels, in_channels // 4, 
                                               kernel_size = 1, stride = 1, padding = 0)
            
            self.skip_connection = nn.Identity()
            self.batchnorm_first_layer = nn.BatchNorm2d(in_channels // 4)
            
            middle_channels = in_channels // 4
        elif stage != 2 and initial == True: # in_channels = *2, out_channels = *4
            self.conv_first_layer = nn.Conv2d(in_channels, in_channels // 2,
                                              kernel_size = 1, stride = 2, padding = 0)
            self.skip_connection = nn.Conv2d(in_channels, out_channels, 
                                             kernel_size = 1, stride = 2, padding = 0)
            self.batchnorm_first_layer = nn.BatchNorm2d(in_channels // 2)
            middle_channels = in_channels // 2

        elif stage != 2 and initial == False: # in_channels = *4, out_channels = *4
            self.conv_first_layer = nn.Conv2d(in_channels, in_channels // 4,
                                              kernel_size = 1, stride = 1, padding = 0)
            self.skip_connection = nn.Identity()
            self.batchnorm_first_layer = nn.BatchNorm2d(in_channels // 4)
            middle_channels = in_channels // 4
        
        self.batchnorm_skip_connection = nn.BatchNorm2d(out_channels)
        self.conv_second_layer = nn.Conv2d(middle_channels, middle_channels, 
                                           kernel_size = 3, stride = 1, padding = 1)
        self.batchnorm_second_layer = nn.BatchNorm2d(middle_channels)
        
        self.conv_third_layer = nn.Conv2d(middle_channels, out_channels,
                                          kernel_size = 1, stride = 1, padding = 0)
        self.batchnorm_third_layer = nn.BatchNorm2d(out_channels)

        self.relu = nn.ReLU()
        
        self.initial = initial


    def forward(self, x):
        if self.initial:
            x_clone = self.batchnorm_skip_connection(self.skip_connection(x))
        else:
            x_clone = x

        x = self.batchnorm_first_layer(self.conv_first_layer(x))
        x = self.relu(x)

        x = self.batchnorm_second_layer(self.conv_second_layer(x))
        x = self.relu(x)

        x = self.batchnorm_third_layer(self.conv_third_layer(x))
        x += x_clone

        x = self.relu(x)

        return x
    

class ResNet50(nn.Module):
    def __init__(self, Bottleneck, num_classes, num_channels):
        super(ResNet50, self).__init__()
        self.conv_first_layer = nn.Conv2d(num_channels, 64, kernel_size = 7, stride = 2, padding = 3)
        self.batchnorm_first_layer = nn.BatchNorm2d(64)
        self.relu = nn.ReLU()
        self.max_pool_second_layer = nn.MaxPool2d(kernel_size = 3, stride = 2, padding = 1, dilation = 1)
        
        self.stage2 = nn.Sequential( # 3 layers, initial 64 --> output 256 channels, 56 x 56 = output size
            Bottleneck(64, 256, stage = 2, initial = True),
            Bottleneck(256, 256, stage = 2, initial = False),
            Bottleneck(256, 256, stage = 2, initial = False)
          )
        
        self.stage3 = nn.Sequential( # 4 layers, bottleneck 128 --> output 512 channels, 28 x 28 = output size
            Bottleneck(256, 512, stage = 3, initial = True),
            Bottleneck(512, 512, stage = 3, initial = False),
            Bottleneck(512, 512, stage = 3, initial = False),
            Bottleneck(512, 512, stage = 3, initial = False)
        )

        self.stage4 = nn.Sequential( # 6 layers, bottleneck 256 --> output 1024 channels, 14 x 14 = output size
            Bottleneck(512, 1024, stage = 4, initial = True),
            Bottleneck(1024, 1024, stage = 4, initial = False),
            Bottleneck(1024, 1024, stage = 4, initial = False),
            Bottleneck(1024, 1024, stage = 4, initial = False),
            Bottleneck(1024, 1024, stage = 4, initial = False),
            Bottleneck(1024, 1024, stage = 4, initial = False)
        )

        self.stage5 = nn.Sequential( # 3 layers, bottleneck 512 --> output 2048 channels, 7 x 7 = output size
            Bottleneck(1024, 2048, stage = 5, initial = True),
            Bottleneck(2048, 2048, stage = 5, initial = False),
            Bottleneck(2048, 2048, stage = 5, initial = False)
        )
        
        self.avgpool = nn.AdaptiveAvgPool2d((1,1))
        self.fc = nn.Linear(2048, num_classes)



    def forward(self,x):
        x = self.relu(self.batchnorm_first_layer(self.conv_first_layer(x)))
        x = self.max_pool_second_layer(x)

        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        x = self.stage5(x)
        
        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)

        #########################
        #  Froward Propagation  #
        #########################

        return x