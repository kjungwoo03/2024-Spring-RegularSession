#CustomDataset.py
import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor

from PIL import Image

"""
MetaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):

    def __init__(self, dataset_direc:str, df:pd.DataFrame, transform = None) -> None:
        
        # 3000개의 이미지를 담고있는 DataSet 디렉토리의 경로입니다.
        self.dataset_direc= dataset_direc

        self.df = df.reset_index(drop=True)

        self.to_tensor = ToTensor() # 파이토치에서는 모든 인풋을 torch.Tensor()로 바꿔줘야합니다.

        self.transform = transform

    # __init__() 함수에서 받은 데이터프레임에 포함된 전체 데이터포인트의 수를 반환하도록 해주세요
    def __len__(self) -> int :
        return len(self.df)

    def __getitem__(self, idx:int):
        # __init__() 함수에서 받은 데이터프레임의 각 행에서 받은 FileName, StrLabel, self.dataset_direc, Label을 이용해 이미지 데이터와 레이블을 반환해주세요
        
        img_name = os.path.join(self.dataset_direc, self.df.StrLabel.iloc[idx], self.df.FileName.iloc[idx])
        image = Image.open(img_name)
        label = self.df.Label.iloc[idx]

        image = self.to_tensor(image)

        if self.transform:
            image = self.transform(image)

        return image, label
