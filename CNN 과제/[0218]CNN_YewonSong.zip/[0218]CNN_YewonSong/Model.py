import torch
import torch.nn as nn
import torch.nn.functional as F

import pandas as pd
import numpy as np

"""
[Batch, Channel, 224, 224]의 input을 받았을 때,
최종적으로 sigmoid activation function에 들어갈 값을 반환하는 ResBottleNeck, ResNet50 Class를 정의해주세요.
즉, 정의된 ResNet50의 output 값은 확률이 아니라 sigmoid에 들어가는 값이 됩니다.
"""

class ResBottleNeck(nn.Module):
    def __init__(self, in_c, middle_c, out_c, stage, first_bottle):
        super(ResBottleNeck, self).__init__()

        if stage == 2 and first_bottle == True:
            self.conv_layer1 = nn.Conv2d(in_c, in_c, kernel_size=1, stride=1, padding=0)
            self.bn_layer1 = nn.BatchNorm2d(in_c)

            self.conv_layer2 = nn.Conv2d(in_c, in_c, 3, 1, 1)
            self.bn_layer2 = nn.BatchNorm2d(in_c)

            self.conv_layer3 = nn.Conv2d(in_c, out_c, 1, 1, 0)
            self.bn_layer3 = nn.BatchNorm2d(out_c)

            self.skip_conn = nn.Conv2d(in_c, out_c, 1, 1, 0)
            self.bn_skip_conn = nn.BatchNorm2d(out_c)

        elif stage != 2 and first_bottle == True:
            self.conv_layer1 = nn.Conv2d(in_c, middle_c, kernel_size = 1, stride = 2, padding = 0)
            self.bn_layer1 =  nn.BatchNorm2d(in_c//2)

            self.conv_layer2 = nn.Conv2d(middle_c, middle_c, 3, 1, 1)
            self.bn_layer2 = nn.BatchNorm2d(in_c//2)

            self.conv_layer3 = nn.Conv2d(middle_c, out_c, 1, 1, 0)
            self.bn_layer3 = nn.BatchNorm2d(out_c)

            self.skip_conn = nn.Conv2d(in_c, out_c, 1, 2, 0)
            self.bn_skip_conn = nn.BatchNorm2d(out_c)

        if first_bottle == False :
            self.conv_layer1 = nn.Conv2d(in_c, middle_c, 1, 1, 0)
            self.bn_layer1 = nn.BatchNorm2d(middle_c)

            self.conv_layer2 = nn.Conv2d(middle_c, middle_c, 3, 1, 1)
            self.bn_layer2 = nn.BatchNorm2d(middle_c)

            self.conv_layer3 = nn.Conv2d(middle_c, out_c, 1, 1, 0)
            self.bn_layer3 = nn.BatchNorm2d(out_c)

            self.skip_conn = nn.Identity()
            self.bn_skip_conn = nn.BatchNorm2d(out_c)

        self.relu = nn.ReLU()
        self.first_bottle = True

    def forward(self, x):
        x_clone = self.bn_skip_conn(self.skip_conn(x))

        x = self.bn_layer1(self.conv_layer1(x))
        x = self.relu(x)

        x = self.bn_layer2(self.conv_layer2(x))
        x = self.relu(x)

        x = self.bn_layer3(self.conv_layer3(x))
        x = x + x_clone
        x = self.relu(x)

        return x


class ResNet50(nn.Module):
    def __init__(self, Bottleneck, num_classes, num_channels):
        super(ResNet50, self).__init__()

        #Stage 1
        self.conv_layer1 = nn.Conv2d(num_channels, 64, kernel_size = 7, stride = 2, padding = 3)
        self.bn_layer1 = nn.BatchNorm2d(64)
        self.relu = nn.ReLU()
        self.maxpool = nn.MaxPool2d(kernel_size = 3, stride = 2, padding = 1, dilation = 1)

        #Stage 2 (3 layers)
        self.stage2 = nn.Sequential(
            Bottleneck(in_c = 64, middle_c = 64, out_c = 256, stage = 2, first_bottle = True),
            Bottleneck(256, 64, 256, stage = 2, first_bottle = False),
            Bottleneck(256, 64, 256, stage = 2, first_bottle = False)
          )

        #Stage 3 (4 layers)
        self.stage3 = nn.Sequential(
            Bottleneck(256, 128, 512, stage = 3, first_bottle = True),
            Bottleneck(512, 128, 512, stage = 3, first_bottle = False),
            Bottleneck(512, 128, 512, stage = 3, first_bottle = False),
            Bottleneck(512, 128, 512, stage = 3, first_bottle = False),
        )

        #Stage4 (6 layers)
        self.stage4 = nn.Sequential(
            Bottleneck(512, 256, 1024, stage = 4, first_bottle = True),
            Bottleneck(1024, 256, 1024, stage = 4, first_bottle = False),
            Bottleneck(1024, 256, 1024, stage = 4, first_bottle = False),
            Bottleneck(1024, 256, 1024, stage = 4, first_bottle = False),
            Bottleneck(1024, 256, 1024, stage = 4, first_bottle = False),
            Bottleneck(1024, 256, 1024, stage = 4, first_bottle = False)
        )

        #Stage5 (3 layers)
        self.stage5 = nn.Sequential(
            Bottleneck(1024, 512, 2048, stage = 5, first_bottle = True),
            Bottleneck(2048, 512, 2048, stage = 5, first_bottle = False),
            Bottleneck(2048, 512, 2048, stage = 5, first_bottle = False)
        )

        self.avgpool = nn.AdaptiveAvgPool2d((1,1))
        self.fc = nn.Linear(2048, num_classes)

    def forward(self,x):
        x = self.bn_layer1(self.conv_layer1(x))
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.stage2(x)
        x = self.stage3(x)
        x = self.stage4(x)
        x = self.stage5(x)

        x = self.avgpool(x)

        x = x.view(x.size(0), -1)
        x = self.fc(x)

        return x
