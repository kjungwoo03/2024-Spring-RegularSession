import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor

from PIL import Image

class CustomImageDataset(Dataset):
    def __init__(self, dataset_direc:str, df:pd.DataFrame, transform=None) -> None:
        self.dataset_direc=dataset_direc
        self.df=df.reset_index(drop=True)
        self.to_tensor=ToTensor()
        self.transform=transform
    def __len__(self) -> int:
        return len(self.df)
    def __getitem__(self, idx:int):
        img_name=self.df.loc[idx, 'FileName']
        strlabel=self.df.loc[idx, 'StrLabel']
        label=self.df.loc[idx, 'Label']
        img_path=os.path.join(self.dataset_direc, strlabel, img_name)
        
        image=Image.open(img_path)
        image=self.to_tensor(image)
        
        if self.transform:
            image=self.transform(image)
        
        return image, label