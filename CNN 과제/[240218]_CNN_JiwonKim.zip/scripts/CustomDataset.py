import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor

from PIL import Image

"""
MetaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):

    def __init__(self, dataset_direc:str, df:pd.DataFrame, transform = None):
        
        # 3000개의 이미지를 담고있는 DataSet 디렉토리의 경로
        self.dataset_direc= str(dataset_direc)

        #데이터프레임을 저장 + 인덱스 제거 및 재할당
        self.df = df.reset_index(drop=True)
        
        #이미지를 텐서로 변환 (파이토치에서는 모든 인풋을 torch.Tensor()로 바꾸어 함)
        self.to_tensor = ToTensor()
        
        #transform 변수를 저장
        self.transform = transform

    # __init__() 함수에서 받은 df에 포함된 전체 데이터포인트의 수를 반환
    def __len__(self) :
        return len(self.df) #len 함수는 int 값만을 반환
    
    #__init__에서 받은 df의 정보를 활용해 image와 label을 반환
    def __getitem__(self, idx:int):
        # __init__() 함수에서 받은 데이터프레임의 각 행에서 받은 FileName, StrLabel, self.dataset_direc, Label을 이용해 이미지 데이터와 레이블을 반환해주세요
        # 각 파일에 맞는 img파일의 디렉토리를 반환 
        img_name = os.path.join(self.dataset_direc, self.df.loc[idx,'StrLabel'], self.df.loc[idx,'FileName'])
        #dataset/Filename
        #dataset/StrLabel/FileName
        
        #img파일 가져오기
        image = Image.open(final_directory)
        
        #해당 img 파일의 label 정보 가져오기
        label = self.df['Label'].iloc[idx]

        #PIL Image 클래스 인스턴스로 정의된 image를 tensor로 변환
        image = self.to_tensor(image)

        #적절한 transformation 수행
        if self.transform:
            image = self.transform(image)

        return image, label