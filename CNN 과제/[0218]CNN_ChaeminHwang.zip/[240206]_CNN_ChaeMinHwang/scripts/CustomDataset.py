import os
import pandas as pd
import torch
from torch.utils.data import Dataset
from torchvision.transforms import ToTensor

from PIL import Image

"""
MetaData.csv를 나누어 만든 train, val, test 데이터프레임에 담긴 이미지와 레이블을 반환해주는 CustomImageDataset을 만들어주세요
참고자료 : https://pytorch.org/tutorials/beginner/data_loading_tutorial.html
"""

class CustomImageDataset(Dataset):
    def __init__(self, dataset_direc:str, df:pd.DataFrame, transform=None):
        self.dataset_direc= dataset_direc

        self.df = df.reset_index(drop=True)

        self.to_tensor = ToTensor() # 파이토치에서는 모든 인풋을 torch.Tensor()로 바꿔줘야합니다.

        self.transform = transform

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx:int):
        # 데이터프레임 구조에 맞게 경로 구성 (예시는 'dataset_direc/FolderPath/FileName')
        path_name = os.path.join(self.dataset_direc, self.df.iloc[idx, 1], self.df.iloc[idx, 0])
        image = Image.open(path_name)
        label = self.df.iloc[idx, 2]
        
        image = self.to_tensor(image)

        if self.transform:
            image = self.transform(image)

            
        return image, label